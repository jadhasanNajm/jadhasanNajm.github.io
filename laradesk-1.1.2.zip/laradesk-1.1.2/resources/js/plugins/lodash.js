import lodash from 'lodash';

window._ = lodash;
